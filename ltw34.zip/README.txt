Ana Margarida Ruivo Loureiro 201705749 
Gonçalo Santos Oliveira	201705494
João Miguel Ribeiro de Castro Silva Martins up201707311

O trabalho foi igualmente dividido por todos os membros do grupo.

O script de base de dados encontra-se na pasta 'database' e tem o nome 'loaddb.sh'

Algumas credenciais de utilizadores ja existentes:
ana@mail.com Golden_Biles99
goncalo@mail.com    SuPErtUx4LiF
joao@mail.com   picoCTF{p3nt3st1ng_4_n00bs_wefdw3e1}

Bibliotecas utilizadas:

 - php-gd para manipulacao de imagens (com a utilização do código exemplo do professor Restivo)
 - php-sqlite3 para interagir com a base de dados sqlite

Além disso utilizamos para o icon de lupa de pesquisa do Google Fonts e um smile nas páginas de erro do fontawesome.
Usou-se ainda a API do Google Maps para apresentação de um mapa com um marcador a apontar para a localização da casa.
