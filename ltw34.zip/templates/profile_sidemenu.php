
<?php
function drawSideMenu() { ?>

<div class="side-menu">
        <a id="reservations" href="../pages/profile_reservation_page.php">Reservations</a>
        <a id="info" href="../pages/profile.php">Info</a>
        <a id="houses" href="../pages/profile_houses_page.php">Houses</a>
</div>
    

<?php } ?>
