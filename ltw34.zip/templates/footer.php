<?php 
  function drawFooter() { ?>
      </div>
      <footer>
        <div id="contacts">
          <a href="https://www.youtube.com/watch?v=fWNaR-rxAic">Contacts</a>
        </div>
        <div>
          <a href="https://www.youtube.com/watch?v=QNJL6nfu__Q">About Us</a>
        </div>
        <div id="atname">
          <p>&copy;2019 HousesOfTheWorld&trade;</p>
        </div>
      </footer>
    </div>
  </body>
</html>
<?php } ?>
